import cs241e.assignments.*
import cs241e.assignments.Assembler.*
import cs241e.assignments.CodeBuilders.*
import cs241e.assignments.MemoryManagement.*
import cs241e.assignments.ProgramRepresentation.*
import cs241e.assignments.Reg
import cs241e.assignments.Transformations.*
import cs241e.mips.*
import org.scalatest.funsuite.AnyFunSuite
import cs241e.assignments.mipsHelpers.printReg
import cs241e.assignments.mipsHelpers.printVar

class A6TestsL2 extends AnyFunSuite {
  test("scala") {
    def main(a: Int, b: Int) = { a + b }
    println(main(1, 2))
  }
  test("lacs") {
    val a = new Variable("a")
    val b = new Variable("b")
    val main = new Procedure("main", Seq(a, b))
    main.code = binOp(read(Reg.result, a), plus, read(Reg.result, b))
    val machineCode = compilerA5(Seq(main))
    val endState = A4.loadAndRun(
      machineCode,
      register1 = Word(encodeSigned(1)),
      register2 = Word(encodeSigned(2)),
      debug = false
    )
    println(decodeSigned(endState.reg(3)))
  }
  test("scala_fact") {
    def main(a: Int, b: Int) = { fact(a) }
    def fact(i: Int): Int = {
      if (i <= 0) 1 else i * fact(i - 1)
    }
    println(main(10, 2))
  }
  test("lacs_fact") {
    val a = new Variable("a")
    val b = new Variable("b")
    val main = new Procedure("main", Seq(a, b))
    val i = new Variable("i")
    val fact = new Procedure("fact", Seq(i))
    main.code = call(fact, read(Reg.result, a))
    //    main.code = Call(fact, Seq(read(Reg.result, a)))
    fact.code = ifStmt(
      read(Reg.result, i),
      leCmp,
      const(0),
      const(1),
      binOp(
        read(Reg.result, i),
        times,
        call(fact, binOp(read(Reg.result, i), minus, const(1)))
      )
    )
    val machineCode = compilerA5(Seq(main, fact))
    val endState = A4.loadAndRun(
      machineCode,
      register1 = Word(encodeSigned(10)),
      register2 = Word(encodeSigned(2)),
      debug = false
    )
    println(decodeSigned(endState.reg(3)))
  }
  def const(i: Int) = block(
    LIS(Reg.result),
    Word(encodeSigned(i))
  )
  test("scala_nested") {
    def main(a: Int, b: Int) = {
      def g(i: Int): Int = {
        a + i
      }
      g(b)
    }
    println(main(10, 2))
  }
  test("lacs_nested") {
    val a = new Variable("a")
    val b = new Variable("b")
    val main = new Procedure("main", Seq(a, b))
    val i = new Variable("i")
    val g = new Procedure("g", Seq(i), outer = Some(main))
    main.code = call(g, read(Reg.result, b))
    g.code = binOp(read(Reg.result, a), plus, read(Reg.result, i))
    val machineCode = compilerA6(Seq(main, g))
    val endState = A4.loadAndRun(
      machineCode,
      register1 = Word(encodeSigned(10)),
      register2 = Word(encodeSigned(2)),
      debug = false
    )
    println(decodeSigned(endState.reg(3)))
  }
  test("scala_closures") {
    def increaseBy(increment: Int): Int => Int = {
      def procedure(x: Int) = { x + increment }
      procedure
    }
    def main(a: Int, b: Int) = {
      val clo: Int => Int = increaseBy(a)
      clo(b)
      // (increaseBy(a))(b)
    }
    println(main(3, 5))
  }

  test("lacs_closure") {
    val a = new Variable("a")
    val b = new Variable("b")
    val clo = new Variable("clo", isPointer = true)
    val main = new Procedure("main", Seq(a, b))
    val increment = new Variable("increment")
    val increaseBy = new Procedure("increaseBy", Seq(increment))
    val x = new Variable("x")
    val procedure = new Procedure("procedure", Seq(x), outer = Some(increaseBy))
    increaseBy.code = Closure(procedure)
    procedure.code = block(
      read(Reg(11), x),
      binOp(read(Reg.result, x), plus, read(Reg.result, increment))
    )
    val parameter = new Variable("parameter")
    main.code = Scope(
      Seq(clo),
      block(
        Comment("asn clo to increase by a"),
        assign(clo, call(increaseBy, read(Reg.result, a))),
        //      assign(clo, CallClosure(Closure(increaseBy), Seq(read(Reg.result, a)), Seq(parameter))),
        Comment("call clo with b"),
        read(Reg(12), b),
        CallClosure(
          read(Reg.result, clo),
          Seq(read(Reg.result, b)),
          Seq(parameter)
        )
      )
      //      CallClosure(call(increaseBy, read(Reg.result, a)), Seq(read(Reg.result, b)), Seq(parameter)))
      //      CallClosure(CallClosure(???), Seq(???, ???, ???), ???)
      //      CallClosure(???, Seq(???, CallClosure(???), ???), ???)
    )
    // main.code = CallClosure(
    //   call(increaseBy, read(Reg.result, a)),
    //   Seq(read(Reg.result, b)),
    //   Seq(parameter)
    // )
    // Scope(
    //   Seq(clo),
    //   block(
    //     assign(clo, call(increaseBy, read(Reg.result, a))),
    //     //      assign(clo, CallClosure(Closure(increaseBy), Seq(read(Reg.result, a)), Seq(parameter))),
    //     CallClosure(
    //       read(Reg.result, clo),
    //       Seq(read(Reg.result, b)),
    //       Seq(parameter)
    //     )
    //   )
    // CallClosure(call(increaseBy, read(Reg.result, a)), Seq(read(Reg.result, b)), Seq(parameter)))
    //   //      CallClosure(CallClosure(???), Seq(???, ???, ???), ???)
    //   //      CallClosure(???, Seq(???, CallClosure(???), ???), ???)
    // )
    val machineCode = compilerA6(Seq(main, increaseBy, procedure))
    val endState = A4.loadAndRun(
      machineCode,
      register1 = Word(encodeSigned(3)),
      register2 = Word(encodeSigned(5)),
      debug = true
    )
    println(decodeSigned(endState.reg(3)))
    println(decodeSigned(endState.reg(11)))
    println(decodeSigned(endState.reg(12)))
  }
}

class A6TestsMidterm extends AnyFunSuite {
  test("scala") {
    def f(): Int = {
      var x: Int = 0
      def g(): Int = {
        var x: Int = 0
        def h(y: Int): Int = { j(x + y) }
        x = 5
        h(x)
      }
      def j(z: Int): Int = { x + z }
      x = 1
      g()
    }
    println(f())
  }
  test("lacs") {
    val x1 = new Variable("x")
    val x2 = new Variable("x")
    val y = new Variable("y")
    val z = new Variable("z")
    val a = new Variable("a")
    val b = new Variable("b")
    val main = new Procedure("main", Seq(a, b))
    val f = new Procedure("f", Seq(), Some(main))
    val g = new Procedure("g", Seq(), Some(f))
    val h = new Procedure("h", Seq(y), Some(g))
    val j = new Procedure("j", Seq(z), Some(f))

    f.code = Scope(
      Seq(x1),
      block(
        LIS(Reg.result),
        Word(encodeSigned(1)),
        write(x1, Reg.result),
        call(g)
      )
    )

    g.code = Scope(
      Seq(x2),
      block(
        LIS(Reg.result),
        Word(encodeSigned(5)),
        write(x2, Reg.result),
        call(h, read(Reg.result, x2))
      )
    )

    h.code = block(
      call(j, binOp(read(Reg.result, x2), plus, read(Reg.result, y)))
    )

    j.code = block(
      binOp(read(Reg.result, x1), plus, read(Reg.result, z))
    )

    main.code = block(
      call(f)
    )

    val machineCode = compilerA6(Seq(main, f, g, h, j))
    val endState = A4.loadAndRun(
      machineCode,
      debug = false
    )
    println(decodeSigned(endState.reg(3)))
  }
  test("hmmmmm") {
    lazy val variable17 = new Variable("temp", isPointer = false);
    lazy val variable8 = new Variable("nested2x", isPointer = false);
    lazy val variable26 = new Variable("nested1unused", isPointer = false);
    lazy val variable2 = new Variable("mainb", isPointer = false);
    lazy val variable4 = new Variable("nested1x", isPointer = false);
    lazy val variable3 = new Variable("temp", isPointer = false);
    lazy val variable27 = new Variable("nested22unused", isPointer = false);
    lazy val variable9 = new Variable("temp", isPointer = false);
    lazy val variable16 = new Variable("nested22x", isPointer = false);
    lazy val variable24 = new Variable("mainx", isPointer = false);
    lazy val variable7 = new Variable("temp", isPointer = false);
    lazy val variable22 = new Variable("nested3x", isPointer = false);
    lazy val variable18 = new Variable("temp", isPointer = false);
    lazy val variable20 = new Variable("temp", isPointer = false);
    lazy val variable14 = new Variable("temp", isPointer = false);
    lazy val variable11 = new Variable("temp", isPointer = false);
    lazy val variable19 = new Variable("temp", isPointer = false);
    lazy val variable23 = new Variable("nested2unused", isPointer = false);
    lazy val variable10 = new Variable("temp", isPointer = false);
    lazy val variable15 = new Variable("temp", isPointer = false);
    lazy val variable25 = new Variable("nested3unused", isPointer = false);
    lazy val variable21 = new Variable("temp", isPointer = false);
    lazy val variable5 = new Variable("temp", isPointer = false);
    lazy val variable1 = new Variable("maina", isPointer = false);
    lazy val variable6 = new Variable("temp", isPointer = false);
    lazy val variable13 = new Variable("temp", isPointer = false);
    lazy val variable12 = new Variable("temp", isPointer = false);;
    lazy val proc1 = new Procedure("main", Seq(variable24, variable2), None);
    lazy val proc5 =
      new Procedure("nested3", Seq(variable22, variable25), Some(proc1));
    lazy val proc4 =
      new Procedure("nested22", Seq(variable16, variable27), Some(proc3));
    lazy val proc2 =
      new Procedure("nested1", Seq(variable4, variable26), Some(proc1));
    lazy val proc3 =
      new Procedure("nested2", Seq(variable8, variable23), Some(proc1));
    proc1.code = Scope(
      Seq(variable1),
      Block(
        Seq(
          Block(
            Seq(
              Block(
                Seq(
                  CodeWord(Word("00000000000000000001100000010100")),
                  CodeWord(Word("00000000000000000000000000101010"))
                )
              ),
              VarAccess(Reg(3), variable1, false)
            )
          ),
          Block(
            Seq(
              Block(
                Seq(
                  CodeWord(Word("00000000000000000001100000010100")),
                  CodeWord(Word("00000000000000000000000001100101"))
                )
              ),
              VarAccess(Reg(3), variable2, false)
            )
          ),
          Call(
            proc2,
            Seq(
              Block(
                Seq(
                  CodeWord(Word("00000000000000000001100000010100")),
                  CodeWord(Word("00000000000000000000000000110111"))
                )
              ),
              Block(
                Seq(
                  CodeWord(Word("00000000000000000001100000010100")),
                  CodeWord(Word("00000000000000000000000001111011"))
                )
              )
            ),
            false
          )
        )
      )
    );
    proc2.code = Scope(
      Seq(),
      Block(
        Seq(
          Block(
            Seq(
              Scope(
                Seq(variable3),
                Block(
                  Seq(
                    VarAccess(Reg(3), variable1, true),
                    VarAccess(Reg(3), variable3, false),
                    VarAccess(Reg(3), variable4, true),
                    VarAccess(Reg(4), variable3, true),
                    CodeWord(Word("00000000100000110001100000100010"))
                  )
                )
              ),
              VarAccess(Reg(3), variable1, false)
            )
          ),
          Call(
            proc3,
            Seq(
              Scope(
                Seq(variable5),
                Block(
                  Seq(
                    VarAccess(Reg(3), variable4, true),
                    VarAccess(Reg(3), variable5, false),
                    Scope(
                      Seq(variable6),
                      Block(
                        Seq(
                          VarAccess(Reg(3), variable1, true),
                          VarAccess(Reg(3), variable6, false),
                          VarAccess(Reg(3), variable2, true),
                          VarAccess(Reg(4), variable6, true),
                          CodeWord(Word("00000000100000110001100000100010"))
                        )
                      )
                    ),
                    VarAccess(Reg(4), variable5, true),
                    Block(
                      Seq(
                        CodeWord(Word("00000000100000110000000000011000")),
                        CodeWord(Word("00000000000000000001100000010010"))
                      )
                    )
                  )
                )
              ),
              Block(
                Seq(
                  CodeWord(Word("00000000000000000001100000010100")),
                  CodeWord(Word("00000000000000000000000111001000"))
                )
              )
            ),
            false
          )
        )
      )
    );
    proc3.code = Scope(
      Seq(),
      Block(
        Seq(
          Block(
            Seq(
              Scope(
                Seq(variable7),
                Block(
                  Seq(
                    VarAccess(Reg(3), variable2, true),
                    VarAccess(Reg(3), variable7, false),
                    VarAccess(Reg(3), variable8, true),
                    VarAccess(Reg(4), variable7, true),
                    CodeWord(Word("00000000100000110001100000100010"))
                  )
                )
              ),
              VarAccess(Reg(3), variable2, false)
            )
          ),
          Call(
            proc4,
            Seq(
              Scope(
                Seq(variable9),
                Block(
                  Seq(
                    VarAccess(Reg(3), variable8, true),
                    VarAccess(Reg(3), variable9, false),
                    Scope(
                      Seq(variable10),
                      Block(
                        Seq(
                          VarAccess(Reg(3), variable2, true),
                          VarAccess(Reg(3), variable10, false),
                          VarAccess(Reg(3), variable1, true),
                          VarAccess(Reg(4), variable10, true),
                          CodeWord(Word("00000000100000110001100000100010"))
                        )
                      )
                    ),
                    VarAccess(Reg(4), variable9, true),
                    Block(
                      Seq(
                        CodeWord(Word("00000000100000110000000000011000")),
                        CodeWord(Word("00000000000000000001100000010010"))
                      )
                    )
                  )
                )
              ),
              Block(
                Seq(
                  CodeWord(Word("00000000000000000001100000010100")),
                  CodeWord(Word("00000000000000000000001100010101"))
                )
              )
            ),
            false
          )
        )
      )
    );
    proc4.code = Scope(
      Seq(),
      Block(
        Seq(
          Block(
            Seq(
              Scope(
                Seq(variable11),
                Block(
                  Seq(
                    VarAccess(Reg(3), variable8, true),
                    VarAccess(Reg(3), variable11, false),
                    Block(
                      Seq(
                        CodeWord(Word("00000000000000000001100000010100")),
                        CodeWord(Word("00000000000000000000000000000001"))
                      )
                    ),
                    VarAccess(Reg(4), variable11, true),
                    CodeWord(Word("00000000100000110001100000100000"))
                  )
                )
              ),
              VarAccess(Reg(3), variable8, false)
            )
          ),
          Block(
            Seq(
              Scope(
                Seq(variable12),
                Block(
                  Seq(
                    Scope(
                      Seq(variable13),
                      Block(
                        Seq(
                          Scope(
                            Seq(variable14),
                            Block(
                              Seq(
                                VarAccess(Reg(3), variable2, true),
                                VarAccess(Reg(3), variable14, false),
                                VarAccess(Reg(3), variable8, true),
                                VarAccess(Reg(4), variable14, true),
                                CodeWord(
                                  Word("00000000100000110001100000100010")
                                )
                              )
                            )
                          ),
                          VarAccess(Reg(3), variable13, false),
                          Block(
                            Seq(
                              CodeWord(
                                Word("00000000000000000001100000010100")
                              ),
                              CodeWord(Word("00000000000000000000000000000001"))
                            )
                          ),
                          VarAccess(Reg(4), variable13, true),
                          CodeWord(Word("00000000100000110001100000100000"))
                        )
                      )
                    ),
                    VarAccess(Reg(3), variable12, false),
                    Scope(
                      Seq(variable15),
                      Block(
                        Seq(
                          VarAccess(Reg(3), variable1, true),
                          VarAccess(Reg(3), variable15, false),
                          VarAccess(Reg(3), variable16, true),
                          VarAccess(Reg(4), variable15, true),
                          CodeWord(Word("00000000100000110001100000100010"))
                        )
                      )
                    ),
                    VarAccess(Reg(4), variable12, true),
                    CodeWord(Word("00000000100000110001100000100000"))
                  )
                )
              ),
              VarAccess(Reg(3), variable1, false)
            )
          ),
          Block(
            Seq(
              Scope(
                Seq(variable17),
                Block(
                  Seq(
                    VarAccess(Reg(3), variable8, true),
                    VarAccess(Reg(3), variable17, false),
                    Block(
                      Seq(
                        CodeWord(Word("00000000000000000001100000010100")),
                        CodeWord(Word("00000000000000000000000000000001"))
                      )
                    ),
                    VarAccess(Reg(4), variable17, true),
                    CodeWord(Word("00000000100000110001100000100010"))
                  )
                )
              ),
              VarAccess(Reg(3), variable8, false)
            )
          ),
          Call(
            proc5,
            Seq(
              Scope(
                Seq(variable18),
                Block(
                  Seq(
                    VarAccess(Reg(3), variable1, true),
                    VarAccess(Reg(3), variable18, false),
                    VarAccess(Reg(3), variable2, true),
                    VarAccess(Reg(4), variable18, true),
                    CodeWord(Word("00000000100000110001100000100010"))
                  )
                )
              ),
              Scope(
                Seq(variable19),
                Block(
                  Seq(
                    Block(
                      Seq(
                        CodeWord(Word("00000000000000000001100000010100")),
                        CodeWord(Word("00000000000000000000000000000000"))
                      )
                    ),
                    VarAccess(Reg(3), variable19, false),
                    Block(
                      Seq(
                        CodeWord(Word("00000000000000000001100000010100")),
                        CodeWord(Word("00000000000000000000000001111100"))
                      )
                    ),
                    VarAccess(Reg(4), variable19, true),
                    CodeWord(Word("00000000100000110001100000100010"))
                  )
                )
              )
            ),
            false
          )
        )
      )
    );
    proc5.code = Scope(
      Seq(),
      Block(
        Seq(
          Scope(
            Seq(variable20),
            Block(
              Seq(
                Scope(
                  Seq(variable21),
                  Block(
                    Seq(
                      VarAccess(Reg(3), variable22, true),
                      VarAccess(Reg(3), variable21, false),
                      VarAccess(Reg(3), variable1, true),
                      VarAccess(Reg(4), variable21, true),
                      CodeWord(Word("00000000100000110001100000100000"))
                    )
                  )
                ),
                VarAccess(Reg(3), variable20, false),
                VarAccess(Reg(3), variable2, true),
                VarAccess(Reg(4), variable20, true),
                CodeWord(Word("00000000100000110001100000100000"))
              )
            )
          )
        )
      )
    );

    val machineCode = compilerA6(Seq(proc1, proc2, proc3, proc4, proc5))
    val endState = A4.loadAndRun(
      machineCode,
      debug = true
    )
    println(decodeSigned(endState.reg(3)))
  }
}
