import cs241e.assignments.*
import cs241e.assignments.Assembler.*
import cs241e.assignments.CodeBuilders.*
import cs241e.assignments.MemoryManagement.*
import cs241e.assignments.ProgramRepresentation.{assign, *}
import cs241e.assignments.Transformations.*
import cs241e.mips.*
import org.scalatest.funsuite.AnyFunSuite

class A6TestsL1 extends AnyFunSuite {
  test("scala") {
    def main(a: Int, b: Int): Int = { a + b }
    println(main(1,2))
  }
  test("lacs") {
    val a = new Variable("a")
    val b = new Variable("b")
    val main = new Procedure("main", Seq(a,b))
    main.code = binOp(read(Reg.result, a), plus, read(Reg.result, b))
    val machineCode = compilerA5(Seq(main))
    val endState = A4.loadAndRun(machineCode, register1 = Word(encodeSigned(1)),
      register2 = Word(encodeSigned(2)), debug = false)
    println(decodeSigned(endState.reg(3)))
  }
  test("scala_fact") {
    def main(a: Int, b: Int): Int = { fact(a) }
    def fact(i: Int): Int = {
      val iMinusOne = i-1
      if(i<=0) 1 else i*fact(iMinusOne)
    }
    println(main(10,2))
  }
  def const(i: Int) = block(
    LIS(Reg.result),
    Word(encodeSigned(i))
  )
  test("lacs_fact") {
    val a = new Variable("a")
    val b = new Variable("b")
    val main = new Procedure("main", Seq(a,b))
    val i = new Variable("i")
    val iMinusOne = new Variable("iMinusOne")
    val fact = new Procedure("fact", Seq(i))
    main.code = call(fact, read(Reg.result, a))
    fact.code = Scope(Seq(iMinusOne), block(
      assign(iMinusOne, binOp(read(Reg.result, i), minus, const(1))),
      ifStmt(read(Reg.result, i), leCmp, const(0), const(1),
        binOp(read(Reg.result, i), times, call(fact, read(Reg.result, iMinusOne))))
      // test: f(g())
      // test: reading/writing variables and parameters
    ))
    val machineCode = compilerA5(Seq(main, fact))
    val endState = A4.loadAndRun(machineCode, register1 = Word(encodeSigned(10)),
      register2 = Word(encodeSigned(2)), debug = false)
    println(decodeSigned(endState.reg(3)))
  }
  test("scala_nested") {
    def main(a: Int, b: Int): Int = {
      def g(i: Int): Int = { a + i }
      g(b)
    }
    println(main(10,2))
  }
  test("lacs_nested") {
    val a = new Variable("a")
    val b = new Variable("b")
    val main = new Procedure("main", Seq(a,b))
    val i = new Variable("i")
    val g = new Procedure("g", Seq(i), outer = Some(main))
    main.code = call(g, read(Reg.result, b))
    g.code = binOp(read(Reg.result, a), plus, read(Reg.result, i))
    val machineCode = compilerA6(Seq(main, g))
    val endState = A4.loadAndRun(machineCode, register1 = Word(encodeSigned(10)),
      register2 = Word(encodeSigned(2)), debug = false)
    println(decodeSigned(endState.reg(3)))
  }
//  test("scala_closure") {
//    def increaseBy(increment: Int): Int=>Int = {
//      def procedure(x: Int) = {
//        x + increment
//      }
//      procedure
//    }
//    def main(a: Int, b: Int): Int = {
//      val clo: Int=>Int = increaseBy(a)
//      clo(b)
//      //      (increaseBy(a))(b)
//      //      increaseBy(a)(b)
//    }
//    println(main(3,5))
//  }
//  test("lacs_closure") {
//    val a = new Variable("a")
//    val b = new Variable("b")
//    val clo = new Variable("clo", isPointer = true)
//    val main = new Procedure("main", Seq(a,b))
//    val increment = new Variable("increment")
//    val increaseBy = new Procedure("increaseBy", Seq(increment))
//    val x = new Variable("x")
//    val procedure = new Procedure("procedure", Seq(x), outer = Some(increaseBy))
//    procedure.code = binOp(read(Reg.result, x), plus, read(Reg.result, increment))
//    increaseBy.code = Closure(procedure)
//    val parameter = new Variable("parameter")
//    main.code = Scope(Seq(clo), block(
//      assign(clo, call(increaseBy, read(Reg.result, a))),
//      CallClosure(read(Reg.result, clo), Seq(read(Reg.result, b)), Seq(parameter)),
//      // also test:
//      //  CallClosure(call(increaseBy, read(Reg.result, a)), Seq(read(Reg.result, b)), Seq(parameter))
//      //  assign(clo, CallClosure(Closure(increaseBy), Seq(read(Reg.result, a)), Seq(parameter))),
//      //  CallClosure(CallClosure(???), Seq(???, ???, ???), ???)
//      //  CallClosure(???, Seq(???, CallClosure(???), ???), ???)
//      //
//    ))
//    val machineCode = compilerA6(Seq(main, increaseBy, procedure))
//    val endState = A4.loadAndRun(machineCode, register1 = Word(encodeSigned(3)),
//      register2 = Word(encodeSigned(5)), debug = false)
//    println(decodeSigned(endState.reg(3)))
//  }
  test("scala_double_nested") {
    def main(a: Int, b: Int): Int = {
      def f(x: Int): Int = {
        def g(y: Int): Int = {
          x + y + a
        }

        g(b)
      }

      f(b)
    }

    println(main(5, 3)) // Expected output: 5 + 3 + 5 = 13
  }

  test("lacs_double_nested") {
    val a = new Variable("a")
    val b = new Variable("b")
    val main = new Procedure("main", Seq(a, b))
    val x = new Variable("x")
    val y = new Variable("y")
    val f = new Procedure("f", Seq(x), outer = Some(main))
    val g = new Procedure("g", Seq(y), outer = Some(f))
    g.code = binOp(binOp(read(Reg.result, x), plus, read(Reg.result, y)), plus, read(Reg.result, a))
    f.code = call(g, read(Reg.result, b))
    main.code = call(f, read(Reg.result, b))
    val machineCode = compilerA6(Seq(main, f, g))
    val endState = A4.loadAndRun(machineCode, register1 = Word(encodeSigned(5)),
      register2 = Word(encodeSigned(3)), debug = false)
    println(decodeSigned(endState.reg(3))) // Expected output: 13
  }

  test("scala_nested_recursion") {
    def main(a: Int): Int = {
      def fact(n: Int): Int = {
        def multiply(i: Int, acc: Int): Int = {
          if (i <= 1) acc
          else multiply(i - 1, i * acc)
        }

        multiply(n, 1)
      }

      fact(a)
    }

    println(main(5)) // Expected output: 120
  }

  test("lacs_nested_recursion") {
    val a = new Variable("a")
    val n = new Variable("n")
    val i = new Variable("i")
    val acc = new Variable("acc")
    val main = new Procedure("main", Seq(a))
    val fact = new Procedure("fact", Seq(n), outer = Some(main))
    val multiply = new Procedure("multiply", Seq(i, acc), outer = Some(fact))
    multiply.code = ifStmt(read(Reg.result, i), leCmp, const(1), read(Reg.result, acc),
      call(multiply, binOp(read(Reg.result, i), minus, const(1)), binOp(read(Reg.result, i), times, read(Reg.result, acc))))
    fact.code = call(multiply, read(Reg.result, n), const(1))
    main.code = call(fact, read(Reg.result, a))
    val machineCode = compilerA6(Seq(main, fact, multiply))
    val endState = A4.loadAndRun(machineCode, register1 = Word(encodeSigned(5)), debug = false)
    println(decodeSigned(endState.reg(3))) // Expected output: 120
  }

  test("scala_nested_variable_shadowing") {
    def main(a: Int): Int = {
      def f(a: Int): Int = {
        def g(a: Int): Int = {
          a + 1
        }

        g(a * 2)
      }

      f(a + 3)
    }

    println(main(2)) // Expected output: ((2 + 3) * 2) + 1 = 11
  }

  test("lacs_nested_variable_shadowing") {
    val aOuter = new Variable("a")
    val aInner1 = new Variable("a")
    val aInner2 = new Variable("a")
    val main = new Procedure("main", Seq(aOuter))
    val f = new Procedure("f", Seq(aInner1), outer = Some(main))
    val g = new Procedure("g", Seq(aInner2), outer = Some(f))
    g.code = binOp(read(Reg.result, aInner2), plus, const(1))
    f.code = call(g, binOp(read(Reg.result, aInner1), times, const(2)))
    main.code = call(f, binOp(read(Reg.result, aOuter), plus, const(3)))
    val machineCode = compilerA6(Seq(main, f, g))
    val endState = A4.loadAndRun(machineCode, register1 = Word(encodeSigned(2)), debug = false)
    println(decodeSigned(endState.reg(3))) // Expected output: 11
  }

}