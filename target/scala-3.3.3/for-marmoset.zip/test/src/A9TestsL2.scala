import cs241e.assignments.*
import org.scalatest.funsuite.AnyFunSuite

class A9TestsL2 extends AnyFunSuite {
  test("test") {
    val prog =
      """
    def main(a: Int, b: Int): Int = {a+b}
    def foo(c: Int, d: (Int,Int)=>Int ): Int = { d(c,c) }
    def bar(): Int = { def baz(bar: Int): Int = { bar } 0 }
      """
    val tree = Lacs.scanAndParse(prog)
    println(tree)
    val typedProcedures = Typer.typeTree(tree)
    println(typedProcedures)
  }
  test("test2") {
    def good(prog: String) = Lacs.scanAndParseAndType(prog)
    def bad(prog: String) = {
      println(intercept[RuntimeException](Lacs.scanAndParseAndType(prog)))
      assertThrows[RuntimeException](Lacs.scanAndParseAndType(prog))
    }
    good("def main(a: Int, b: Int): Int = {a+b}")
    bad("def main(a: Int, b: Int): Int = {a+c}")
    bad("def main(a: Int, a: Int): Int = {a}")
  }
  test("lacs-nested-procedures-3") { // should fail
    Lacs.scanAndParseAndType(
      """
           def main(a: Int, b: Int): Int = {
             var x: Int;
             var c: Int;
             def proc1(): Int = {
                var y: Int;
                var c: (Int) => Int;
                def proc2(r: Int): Int = {
                  r + 5
                  }
                x = 5;
                c = 2;
                proc2(x)
                }
             b = 4;
             a = 1;
             x = proc1();
             x
             }
           """
    )
  }
}

class A9Tests extends AnyFunSuite {
  def good(prog: String) = Lacs.scanAndParseAndType(prog)
  def bad(prog: String) =
    assertThrows[RuntimeException](Lacs.scanAndParseAndType(prog))
  def print_good(prog: String) = println(good(prog))

  test("good trees") {
    good("def main(a : Int, b: Int): Int = { a+b }")
    good("""
      def main(a : Int, b: Int): Int = { a+b }
      def foo(c: Int, d: (Int,Int)=>Int): Int = { d(c,c) }
    """)
    good("def main(a : Int, b: Int): Int = { a+b*b*a }")
    good("""
      def main(a : Int, b: Int): Int = {
        def factorial(x : Int) : Int = {
          if (x == 0) {
            1
          } else {
            x * factorial(x-1)
          }
        }
        factorial(a+b)
      }
    """)
    good("""
      def main(a : Int, b: Int): Int = {
        def inner(x : Int) : Int = {
          if (a == 0) {
            x
          } else {
            2
          }
        }
        inner(a+b)
      }
    """)
    good("""
      def main(a : Int, b: Int): Int = {
        def inner(x : Int) : Int = {
          if (a == 0) {
            a = 3;
            b
          } else {
            x + a
          }
        }
        inner(a+b)
      }
    """)
    good("""
      def main(a : Int, b: Int): Int = {
        def inner(a : Int) : Int = {
          if (a == 0) {
            a = 3;
            b
          } else {
            a
          }
        }
        inner(a+b)
      }
    """)
    good("""
      def main(a : Int, b: Int): Int = {
        def inner(a : Int) : Int = {
          if (a == 0) {
            a = 3;
            b
          } else {
            a
          }
        }
        inner(a+b)
      }
    """)
    good("""
      def main(a : Int, b: Int): Int = { a+b }
      def foo(c: Int, b: (Int,Int)=>Int): Int = { b(c,c) }
    """)
    good("""
      def main(a : Int, b: Int): Int = {
        def inner(main : Int) : Int = { main }
        inner(a)
      }
    """)
    good("""
      def main(main : Int, b: Int): Int = { main+b }
    """)
    good("""
      def main(a: Int, b: Int): Int = { main(a - 1, b + 1) }
      """)
  }

  test("bad trees") {
    bad("def main(a : Int, a: Int): Int = { a+b }")
    bad("def main(a : Int, b: Int): Int = { a+c }")
    bad("def main(a : Int, a: Int): Int = { a++ }")
    bad("def main(a : Int, b: Int): Int = { c + c }")
    bad("""
      def main(a : Int, b: Int): Int = { a+b }
      def main(c: Int, d: (Int,Int)=>Int): Int = { d(c,c) }
    """)
    bad("""
      def main(a : Int, b: Int): Int = { a+b }
      def main(c : Int, d: Int): Int = { c+d }
    """)
    bad("""
      def main(a : Int, b: Int): Int = { a+b }
      def foo(c : Int, d: Int): Int = { c + main }
    """)
    bad("""
      def main(a: Int): Int = { def main(b: Int): Int = { b } }
      """)
    bad("""
      def main(a: Int): Int = { val c = main; a }
      """)
  }
//  test("single") {
//    good("""
//      def main(main : Int, b: Int): Int = { main+b }
//    """)
//  }
}

class A9Tutorial extends AnyFunSuite {
  test("test_tree1") {
    val prog =
      """
        def main(a : Int, b: Int): Int = { a+b }
      """
    val tree = Lacs.scanAndParse(prog)
    val typedProcedures = Typer.typeTree(tree)
    println(typedProcedures)
  }

  test("test_tree2") {
    val prog =
      """
        def main(a : Int, b: Int): Int = { a+b }
        def foo(c: Int, d: (Int,Int)=>Int): Int = { d(c,c) }
      """
    val tree = Lacs.scanAndParse(prog)
    val typedProcedures = Typer.typeTree(tree)
    println(typedProcedures)
  }

  test("test_lacs_procedures") {
    def good(prog: String) = Lacs.scanAndParseAndType(prog)
    def bad(prog: String) =
      assertThrows[RuntimeException](Lacs.scanAndParseAndType(prog))
//    def bad(prog: String) = println(intercept[RuntimeException](Lacs.scanAndParseAndType(prog)))

    // - Main goal is detect programs synatically valid, but still wrong.
    //    - So for our tests, we want many incorrect programs.
    // - Create a test that violates every *must* requirement given in the specification.
    //    - Ensure your compiler rejects that specific test.
    //    - Separate test for each requirement; otherwise your compiler may detect one, and hence not testing if it
    //      detects the other as well.

    good("def main(a : Int, b: Int): Int = { a+b }")
    bad("def main(a : Int, a: Int): Int = { a+b }")
    bad("def main(a : Int, b: Int): Int = { a+c }")
  }
}
