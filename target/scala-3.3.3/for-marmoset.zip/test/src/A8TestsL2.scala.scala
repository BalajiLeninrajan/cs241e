import cs241e.assignments.*
import cs241e.assignments.Assembler.*
import cs241e.assignments.CodeBuilders.*
import cs241e.assignments.MemoryManagement.*
import cs241e.assignments.Parsing.*
import cs241e.assignments.ProgramRepresentation.*
import cs241e.assignments.Transformations.*
import cs241e.mips.*
import cs241e.scanparse.DFAs.Token
import cs241e.scanparse.Grammars
import org.scalatest.funsuite.AnyFunSuite

class A8TestsL2 extends AnyFunSuite {
  test("simple-grammar") {
    val grammar = Grammars.parseGrammar(
      """
         expr expr op expr
         expr ID
         op +
         op -
         op *
         op /
        """
    )
    println(grammar.nonTerminals)
    println(grammar.terminals)
    println(grammar.start)
    println(grammar.productions)
    println(grammar.productionsExpanding("expr"))

    val tokens =
      Seq(Token("ID"), Token("+"), Token("ID"), Token("*"), Token("ID"))
    val tree = parseCYK(grammar, tokens.toIndexedSeq).get
    println(tree.production)
    println(tree.children(1).production)
    println(tree)

    val badtokens = Seq(Token("ID"), Token("+"), Token("ID"), Token("*"))
    assert(parseCYK(grammar, badtokens.toIndexedSeq) == None)
  }
  test("lacs") {
    println(Lacs.grammar)
    val prog =
      """
      def main(a: Int, b: Int): Int = {a+b*1}
        """
    val tokens = Lacs.scan(prog)
    val tree = parseCYK(Lacs.grammar, tokens.toIndexedSeq).get
    println(tree)
    val tree2 = Lacs.scanAndParse(prog)
    println(tree2)

  }
}
